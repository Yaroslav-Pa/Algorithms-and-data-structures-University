class HuffmanCoding:
    class Node:
        def __init__(self, char=None, freq=0):
            self.char = char
            self.freq = freq
            self.left = None
            self.right = None

    def __init__(self):
        self.codes = {}
        self.reverseMapping = {}
        self.compressedData = bytearray()

    def buildTree(self, frequencies):
        nodes = [self.Node(char, freq) for char, freq in frequencies.items()]

        while len(nodes) > 1:
            nodes.sort(key=lambda x: x.freq)
            left = nodes[0]
            right = nodes[1]
            mergedNode = self.Node(freq=left.freq + right.freq)
            mergedNode.left = left
            mergedNode.right = right
            nodes = nodes[2:] + [mergedNode]

        return nodes[0]

    def buildCodes(self, root, currentCode=""):
        if root is None:
            return
        if root.char is not None:
            self.codes[root.char] = currentCode
            self.reverseMapping[currentCode] = root.char
            return
        self.buildCodes(root.left, currentCode + "0")
        self.buildCodes(root.right, currentCode + "1")

    def encodeText(self, text):
        encodedText = "".join([self.codes[char] for char in text])
        return encodedText

    def padEncodedText(self, encodedText):
        extraPadding = 8 - len(encodedText) % 8
        encodedText += "0" * extraPadding
        paddedInfo = format(extraPadding, "08b")
        encodedText = paddedInfo + encodedText
        return encodedText

    def getByteArray(self, paddedEncodedText):
        if len(paddedEncodedText) % 8 != 0:
            print("Encoded text not properly padded")
            exit(1)
        byteArray = bytearray()
        for i in range(0, len(paddedEncodedText), 8):
            byte = paddedEncodedText[i:i + 8]
            byteArray.append(int(byte, 2))
        return byteArray

    def compress(self, text):
        frequencies = {}
        for char in text:
            frequencies[char] = frequencies.get(char, 0) + 1

        root = self.buildTree(frequencies)
        self.buildCodes(root)
        encodedText = self.encodeText(text)
        paddedEncodedText = self.padEncodedText(encodedText)
        byteArray = self.getByteArray(paddedEncodedText)
        self.compressedData = bytes(byteArray)
        return self.compressedData

    def compressionStats(self):
        originalSize = len(self.codes) * 8
        compressedSize = len(self.compressedData)
        return originalSize, compressedSize

    def decompress(self):
        bitString = ""
        for byte in self.compressedData:
            bits = format(byte, "08b")
            bitString += bits
        extraPadding = bitString[:8]
        extraPadding = int(extraPadding, 2)
        bitString = bitString[8:]
        encodedText = bitString[:-extraPadding]
        currentCode = ""
        decodedText = []
        for bit in encodedText:
            currentCode += bit
            if currentCode in self.reverseMapping:
                char = self.reverseMapping[currentCode]
                decodedText.append(char)
                currentCode = ""
        return "".join(decodedText)

    def setInputFile(self, filePath):
        self.inputFile = filePath

    def writeCompressed(self, outputFile):
        with open(outputFile, "wb") as file:
            file.write(self.compressedData)

    def writeDecompressed(self, outputFile, decodedText):
        with open(outputFile, "w") as file:
            file.write(decodedText)

if __name__ == "__main__":
    inputFileName = "in.txt"
    compressedFileName = "compress.bin"
    decompressedFileName = "out.txt"

    huffmanCoder = HuffmanCoding()
    huffmanCoder.setInputFile(inputFileName)

    with open(huffmanCoder.inputFile, 'r') as file:
        text = file.read()

    compressedData = huffmanCoder.compress(text)

    huffmanCoder.writeCompressed(compressedFileName)

    originalSize, compressedSize = huffmanCoder.compressionStats()
    print(f"Original size: {originalSize} bytes")
    print(f"Compressed size: {compressedSize} bytes")

    decodedText = huffmanCoder.decompress()

    huffmanCoder.writeDecompressed(decompressedFileName, decodedText)
